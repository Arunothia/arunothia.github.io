The code is written in TURBO C++. Operating System - Windows 7
 
